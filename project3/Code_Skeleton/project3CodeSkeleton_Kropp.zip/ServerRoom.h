// CSCI 1300 Fall 2021
// Author: Marlin Kropp
// Recitation: 314 - Bishop
// Project 3 - Server Room header

#include <iostream>
#ifndef SERVERROOM_H
#define SERVERROOM_H

using namespace std;

class ServerRoom{

    private:
        int numHackersDefeated;
        bool cleared;
        int level;
    
    public:
        //constructors
        ServerRoom();

        ServerRoom(int lvl);

        //getters/setters
        int getNumHackersDefeated();

        void clearRoom();

        bool getClear();

        //other member functions
        void defeatHacker();
    
};

#endif