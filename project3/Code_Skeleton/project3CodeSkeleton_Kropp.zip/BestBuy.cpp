// CSCI 1300 Fall 2021
// Author: Marlin Kropp
// Recitation: 314 - Bishop
// Project 3 - best buy member funcitons

#include "BestBuy.h"
#include <iostream>

using namespace std;

BestBuy::BestBuy(){
    priceHike = 1.0;
}

void BestBuy::setPriceHike(double pricePercentIncrease){
    priceHike = priceHike + priceHike * pricePercentIncrease;
    return;
}

double BestBuy::getPriceHike(){
    return priceHike;
}

void BestBuy::printOverview(){
    //TODO: print overview
    return;
}

void BestBuy::buyComputerParts(){
    //TODO: create a function that buys computer parts
    return;
}

void BestBuy::buyAntivirus(){
    //TODO: create a function that will buy antivirus
    return;
}

void BestBuy::buyVPN(){
    //TODO: create a function that will buy VPNs
    return;
}

void BestBuy::buyInternet(){
    //TODO: create a funciton that will buy a higher level internet provider
    return;
}
