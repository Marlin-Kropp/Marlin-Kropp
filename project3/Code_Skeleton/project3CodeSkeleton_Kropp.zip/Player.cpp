// CSCI 1300 Fall 2021
// Author: Marlin Kropp
// Recitation: 314 - Bishop
// Project 3 - Member Functions

#include "Player.h"
#include <iostream>

using namespace std;

Player::Player(string temp){
    name = temp;
    frustrationLvl = 0;
    numCoin = 200;
    internetLvl = 1;
    numVPN = 1;
}

string Player::getName(){
    return name;
}

void Player::setCPU(int CPUs){
    numCPU = CPUs;
}

int Player::getCPU(){
    return numCPU;
}

void Player::setGPU(int GPUs){
    numGPU = GPUs;
}

int Player::getGPU(){
    return numGPU;
}

void Player::setPower(int Power){
    numPowerSupply = Power;
}

int Player::getPower(){
    return numPowerSupply;
}

void Player::setCase(int Case){
    numCase = Case;
}

int Player::getCase(){
    return numCase;
}

void Player::setCard(int Card){
    numCard = Card;
}
        
int Player::getCard(){
    return numCard;
}

void Player::setMaK(int MaK){
    numMouseAndKeys = MaK;
}

int Player::getMaK(){
    return numMouseAndKeys;
}

void Player::setComputer(bool Computer){
    premadeComputer = Computer;
}

bool Player::getComputer(){
    return premadeComputer;
}

void Player::setAntivirus(int Antivirus){
    numAntivirus = Antivirus;
}

int Player::getAntivirus(){
    return numAntivirus;
}

void Player::setVPN(int VPN){
    numVPN = VPN;
}

int Player::getVPN(){
    return numVPN;
}

void Player::setInternet(int lvl){
    internetLvl = lvl;
}

int Player::getInternet(){
    return internetLvl;
}

void Player::setCoin(int Coin){
    numCoin = Coin;
}

int Player::getCoin(){
    return numCoin;
}

void Player::setFilesStolen(int FilesStolen){
    percentFilesStolen = FilesStolen;
}

int Player::getFilesStolen(){
    return percentFilesStolen;
}

void Player::setMatinence(int Matinence){
    percentComputerMatinence = Matinence;
}

int Player::getMatinence(){
    return percentComputerMatinence;
}

void Player::setFrustration(int Level){
    frustrationLvl = Level;
}

int Player::getFrustration(){
    return frustrationLvl;
}

void Player::setHackersDefeated(int defeated){
    numHackersDefeated = defeated;
}

int Player::getHackersDefeated(){
    return numHackersDefeated;
}

void Player::statusUpdate(){
    //TODO: Show status update
    return;
}

void Player::attackHacker(){
    //TODO: implement the attack and display
    return;
}

void Player::speakNPC(){
    //TODO: implement the NPC interactions
    return;
}

void Player::repairComputer(){
    //TODO: repair the computer
    return;
}

void Player::useAntivirus(){
    //TODO: use antivirus
    return;
}

void Player::travelRoom(){
    //TODO: travel the given map class
    return;
}

void Player::browseStack(){
    //TODO: browse stack overflow
    return;
}

void Player::quit(){
    //TODO: print a goodbye message and exit the game
    return;
}

void Player::misfortune(){
    //TODO: write a function for a misfortune
    return;
}

void Player::endTurn(){
    //TODO: implement all of the end of turn processes
    return;
}